<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
	<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</head>
<body>
	<div class="row" style="margin-top: 150px;">
		<div class="col-lg-2"></div>
		<div class="col-lg-8">
			<p style="font-size: 50px; text-align: center;color: #1f0949;">404 <strong style="font-size: 50px; color: #eb1e25;">ERROR</strong></p>
			<p style="font-size: 30px; text-align: center;color: #1f0949;">The Page you are looking for is not available. Please click the below link to go back to the website</strong></p><br>
		</div>
		<div class="col-lg-2"></div>
	</div>
	<div class="row">
		<div class="col-lg-5"></div>
		<div class="col-lg-2">
			<a href="<?php echo e(route('index')); ?>" class="btn btn-info"  style="text-align: center;margin-left: 35px;">BACK TO HOME</a>
		</div>
		<div class="col-lg-5"></div>
	</div>

</body>
</html><?php /**PATH C:\xampp\htdocs\ukuni\vendor\laravel\framework\src\Illuminate\Foundation\Exceptions/views/404.blade.php ENDPATH**/ ?>