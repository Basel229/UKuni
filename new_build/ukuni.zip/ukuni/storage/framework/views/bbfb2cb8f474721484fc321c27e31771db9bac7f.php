<?php $__env->startSection('content'); ?>
<!-- About Us slider -->
<div class="row" style="margin-top: 150px;">
	<div class="col-lg-2"></div>
	<div class="col-lg-8">
		<p style="font-size: 25px; text-align: left;color: #1f0949;">Hello <?php echo e($name); ?>! <strong style="font-size: 25px; color: #eb1e25;">Thank you for applying for <?php echo e($university); ?>. We will contact you sortly. If you have any other query Call us by clicking the button</strong></p>
		<a href="#"  id="changecolor"  class="btn btn-default " style="background-color:#fff; color: #111;border-color: #1f0949; font-family:BusnosAires-light;font-size:20px;width: 200px;"><span >Call Now</span> 
                <i class="fas fa-chevron-right"></i>
              </a>&nbsp;&nbsp;<a href="#"  id="changecolor"  class="btn btn-default " style="background-color:#fff; color: #111;border-color: #1f0949; font-family:BusnosAires-light;font-size:20px;width: 200px;"><span >Explore More</span> 
                <i class="fas fa-chevron-right"></i>
              </a>
	</div>
	<div class="col-lg-2"></div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ukuni\resources\views/thankyou.blade.php ENDPATH**/ ?>