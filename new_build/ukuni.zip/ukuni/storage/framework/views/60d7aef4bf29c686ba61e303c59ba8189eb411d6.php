<?php $__env->startSection('content'); ?>
<!-- About Us slider -->
<div class="row">
			<div id="demo" class="carousel slide" data-ride="carousel">
  
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="images/ukuni_slider/citizenship.jpg" alt="Los Angeles" width="1100" height="300">
      <div class="carousel-caption" >
        <h1 style="font-size: 50px;">CITIZENSHIP</h1>
        <hr width="10%" style="border-top-width: 3px;
    border-top-style: solid;
    border-top-color: #fff;" align="left">
        
<br><br><br><br>
      </div>   
    </div>
   
    
	 
	  </div>

	  
	</div>
		</div>
<br><br>
<!-- About Us slider -->
<!-- About Us Text -->

<div class="row">
	
	<div class="col-lg-8">
		<p style="font-size: 50px; text-align: left;color: #1f0949;">Citizenship <strong style="font-size: 50px; color: #eb1e25;"> By Investment</strong></p>
		<hr width="10%" style="border-top-width: 3px;
    border-top-style: solid;
    border-top-color: #1f0949;" align="left"><br>
    <p style="font-size: 30px; text-align: left;color: #1f0949;">Cyprus </p>
    <ul>
    	<li>Full citizenship within 3 to 6 months</li>
    	<li>No language requirement</li>
    	<li>Automatic citizenship in the EU</li>
    	<li>Must prove legal source of funds</li>
    	<li>Required to invest 2.5 million Euros </li>
    	<li>Must keep investment property for a minimum 3 years (villas, houses, preapproval project) </li>
    	<li>Must keep a residence worth 500,000 Euros to maintain citizenship </li>
    </ul>
    <br>
    <p style="font-size: 30px; text-align: left;color: #1f0949;">Portugal </p>
    <ul>
    	<li>Must invest 350,000 to 400,000 Euros in a pre-approved project</li>
    	<li>Allowed to live and work in Portugal </li>
    	<li>Have access to healthcare and education in Portugal</li>
    	<li>After 5 years is allowed to apply for Portuguese citizenship </li>
    	<li>Eligible to apply for travel in other Schengen countries but not allowed to work </li>
    	<li>Must spend 7 days per year in Portugal</li>
    	
    </ul>
    <br>
    <p style="font-size: 30px; text-align: left;color: #1f0949;">Antigua and Barbuda </p>
    <ul>
    	<li>5 to 6 month processing</li>
    	<li>Full citizenship</li>
    	<li>Can travel up to 140 countries without a visitor visa including UK and Schengen countries</li>
    	<li>Two options</li>
    	<li>Donation to the Government – total US$175,000 for a family of 4 including government and legal cost  </li>
    	<li>Purchase a new 2 or 3 bedroom villa for US$400,000 to US$450,000 plus government fees and legal fees (for a family of 4 around US$100,000) </li>
    	<li>No language requirement </li>
    	<li>Must spend 5 days in a 5 year period to maintain the citizenship </li>
    </ul>
    <br>
    <p style="font-size: 30px; text-align: left;color: #1f0949;">St Kitts and Nevis </p>
    <ul>
    	<li>Fast processing (3 to 6 months)</li>
    	<li>No residency requirements</li>
    	<li>Visa free travel to 152 countries including Europe and UK</li>
    	<li>Can include children up to age 30 parents and grandparents over age 55</li>
    	<li>Can invest in a real estate project US$400,000 plus government fees and legal fees (US$500K) </li>
    	<li>Donation of Under US$200,000 including government fees and legal fees for a family of 4 </li>
    	
    </ul>
    <br>



	
	<br><br>


        <div class="row">
        <div class="col-lg-1"></div>
        <div class="col-lg-10">
            <div class="row">
                <div class="col-lg-6" >
                    <div class="row">
                        
                        <div class="col-lg-11 " >
                        <img src="images/blogs/second_passport.jpg" width="100%">
                        <h5 style="margin-top: 10px;">Why you need a second passport?</h5>
                        <p style="font-size: 13px;font-weight: 700;color: #eb1e25">Article</p>
                        <hr>
                        <p style="font-size: 16px;">
                             
                            Before World War I, you didn’t need a passport for international travel.


                        </p><span style="font-size: 15px;font-weight: 300">December 23, 2020 | Citizenship</span><br><br>
                        
                        <a href="<?php echo e(route('second_passport')); ?>"  id="changecolor" class="btn btn-default " style="background-color:#fff; color: #111;border-color: #1f0949; font-family:BusnosAires-light;font-size:20px;"><span >Read More</span> 
                            <i class="fas fa-chevron-right"></i>
                        </a>
                        <br><br><hr>
                        </div>
                        <div class="col-lg-1"></div>
                    </div>
                </div>


            </div>
        </div>
        <div class="col-lg-1"></div>
        
    </div>


	</div>
	<div class="col-lg-3" >
		<?php echo $__env->make('layouts.assessmentForm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</div>
	<div class="col-lg-1"></div>
</div><br><br>
<!-- About Us Text -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ukuni\resources\views/citizenship.blade.php ENDPATH**/ ?>