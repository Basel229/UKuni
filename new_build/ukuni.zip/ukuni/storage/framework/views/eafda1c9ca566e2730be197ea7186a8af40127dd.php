<?php $__env->startSection('content'); ?>
<div class="row">
			<div id="demo" class="carousel slide" data-ride="carousel">
  
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="images/ukuni_slider/ielts.jpg" alt="Los Angeles" width="1100" height="300">
      <div class="carousel-caption" >
        <h1 style="font-size: 50px;">STUDY ABROAD</h1>
        <hr width="10%" style="border-top-width: 3px;
    border-top-style: solid;
    border-top-color: #fff;" align="left">

        
<br>
<br>


<br><br>
      </div>   
    </div>
   
    
	 
	  </div>

	  
	</div>
		</div>

<!-- About Us slider -->
<!-- Search Filter -->
<div class="row" style="background-color: #eb1e25;">
	
	<div class="col-lg-2"></div>
	<div class="col-lg-8" ><br>
		<p style="font-size: 35px; text-align: center;color: #fff;">Search <strong style="font-size: 35px; color: #fff;">University. . . </strong></p>
		    
    <form method="POST" action="<?php echo e(route('countryselected')); ?>" class="form-inline">
    	<?php echo e(csrf_field()); ?>

    	<select name="country" class="form-control form_field_size" style="height: 45px;
			width: 80%;">
    		<option value="#">Select Country First</option>
    		<option value="Study in UK">Study in UK</option>
    		<option value="Study in USA">Study in USA</option>
            <option value="Study in Australia">Study in Australia</option>
            <option value="Study in New Zealand">Study in New Zealand</option>
            <option value="Study in Canada">Study in Canada</option>
            <option value="Study in Ireland">Study in Ireland</option>
            <option value="Study in Middle East">Study in Middle East</option>
    	</select>&nbsp;
    	

    	
    	<input type="submit" name="submit" class="btn btn-info" style="height: 45px;width: 150px">
    </form>
	<br><br><br>
	</div>
	<div class="col-lg-2"></div>
</div>
<!-- Search Filter -->
<!-- About Us Text --><br><br>
<div class="row">
	
	<div class="col-lg-8">
		<p style="font-size: 50px; text-align: left;color: #1f0949;">About <strong style="font-size: 50px; color: #eb1e25;">Study Abroad </strong></p>
		<hr width="10%" style="border-top-width: 3px;
    border-top-style: solid;
    border-top-color: #1f0949;" align="left">

    <p style="font-size: 20px;">It is estimated that there are more than 7,000 universities across the world, how to choose between them is becoming more challenging. It is our role to assist you to make the right informative choice and help you to get accepted in the university of your choice. Contact us.</p><br>

    <br><br>

    <!-- Blogs section -->
                <div class="row">
                <div class="col-lg-6" >
                    <div class="row">
                        
                        <div class="col-lg-11 " >
                        <img src="images/blogs/canadian_way_of_life.jpg" width="100%">
                        <a href="<?php echo e(route('canadian_way_of_life')); ?>"><h5 style="margin-top: 10px;">Canadian Way of Life</h5></a>
                        <p style="font-size: 13px;font-weight: 700;color: #eb1e25">Article</p>
                        <hr>
                        <p style="font-size: 16px;">
                             
                            Canada consistently ranks among the best place to live in numerous studies. In both 2018 and 2019


                        </p>
                        <span style="font-size: 15px;font-weight: 300">January 22, 2020 | Study In Canada</span><br><br>
                        <a href="<?php echo e(route('canadian_way_of_life')); ?>"  id="changecolor" class="btn btn-default " style="background-color:#fff; color: #111;border-color: #1f0949; font-family:BusnosAires-light;font-size:20px;"><span >Read More</span> 
                            <i class="fas fa-chevron-right"></i>
                        </a>
                        <br><br><hr>
                        </div>
                        <div class="col-lg-1"></div>
                    </div>
                </div>
                <div class="col-lg-6" >
                    <div class="row">
                        
                        <div class="col-lg-11" >
                        <img src="images/blogs/pakistani_student_canada.jpg" width="100%">
                        <h5 style="margin-top: 10px;">Pakistani Student Canada</h5>
                        <p style="font-size: 13px;font-weight: 700;color: #eb1e25">Article</p>
                        <hr>
                        <p style="font-size: 16px;">
                             
                            20-Day Canada Study Permit Processing Via Student Direct Stream


                        </p>
                        <span style="font-size: 15px;font-weight: 300">January 22, 2020 | Study In Canada</span><br>
                        
                        <br>
                        <a href="<?php echo e(route('pakistani_student_canada')); ?>"  id="changecolor" class="btn btn-default " style="background-color:#fff; color: #111;border-color: #1f0949; font-family:BusnosAires-light;font-size:20px;"><span >Read More</span> 
                            <i class="fas fa-chevron-right"></i>
                        </a>
                        <br><br><hr>
                    </div>
                    <div class="col-lg-1"></div>
                    </div>  
                </div>

            </div>
                <br><br>

            <div class="row">
                <div class="col-lg-6" >
                    <div class="row">
                        
                        <div class="col-lg-11" >
                        <img src="images/blogs/facts_about_studying_in_australia.jpg" width="100%">
                        <h5 style="margin-top: 10px;">Facts about studying in Australia</h5>
                        <p style="font-size: 13px;font-weight: 700;color: #eb1e25">Article</p>
                        <hr>
                        <p style="font-size: 16px;">
                             
                                Studying in Australia is a fantastic way to further your education and boost your career prospects.

                        </p>
                        <span style="font-size: 15px;font-weight: 300">December 23, 2020 | Study In Australia</span><br>
                        
                        <br>
                        <a href="<?php echo e(route('facts_about_studying_in_australia')); ?>"  id="changecolor" class="btn btn-default " style="background-color:#fff; color: #111;border-color: #1f0949; font-family:BusnosAires-light;font-size:20px;"><span >Read More</span> 
                            <i class="fas fa-chevron-right"></i>
                        </a>
                        <br><br><hr>
                    </div>
                    <div class="col-lg-1"></div>
                    </div>  
                </div>
                <div class="col-lg-6" >
                    <div class="row">
                        
                        <div class="col-lg-11" >
                        <img src="images/blogs/after_graduation.jpg" width="100%">
                        <h5 style="margin-top: 10px;">After graduation</h5>
                        <p style="font-size: 13px;font-weight: 700;color: #eb1e25">Article</p>
                        <hr>
                        <p style="font-size: 16px;">
                             
                            Once you’ve completed your course, you have some decisions to make, whether you stay in Australia or return home.


                        </p>
                        <span style="font-size: 15px;font-weight: 300">January 23, 2020 | Study In Australia</span><br><br>
                        
                        
                        <a href="<?php echo e(route('after_graduation')); ?>"  id="changecolor" class="btn btn-default " style="background-color:#fff; color: #111;border-color: #1f0949; font-family:BusnosAires-light;font-size:20px;"><span >Read More</span> 
                            <i class="fas fa-chevron-right"></i>
                        </a>
                        <br><br><hr>
                    </div>
                    <div class="col-lg-1"></div>
                    </div>  
                </div>
            </div>

            <div class="row">

                <div class="col-lg-6" >
                    <div class="row">
                        
                        <div class="col-lg-11" >
                        <img src="images/blogs/usf_scholarship.jpg" width="100%">
                        <h5 style="margin-top: 10px;">USF Scholarship</h5>
                        <p style="font-size: 13px;font-weight: 700;color: #eb1e25">News</p>
                        <hr>
                        <p style="font-size: 16px;">
                             
                            The University of South Florida (USF) is offering some generous scholarships for top students 


                        </p>
                        <span style="font-size: 15px;font-weight: 300">January 23, 2020 | News</span><br><br>
                        
                        
                        <a href="<?php echo e(route('usf_scholarship')); ?>"  id="changecolor" class="btn btn-default " style="background-color:#fff; color: #111;border-color: #1f0949; font-family:BusnosAires-light;font-size:20px;"><span >Read More</span> 
                            <i class="fas fa-chevron-right"></i>
                        </a>
                        <br><br><hr>
                    </div>
                    <div class="col-lg-1"></div>
                    </div>  
                </div>
            </div>        

    <!-- Blogs Section -->

	</div>
	<div class="col-lg-3 university-logo" >
		<?php echo $__env->make('layouts.queryForm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</div>
	<div class="col-lg-1"></div>
</div><br><br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ukuni\resources\views/main/study_abroad.blade.php ENDPATH**/ ?>