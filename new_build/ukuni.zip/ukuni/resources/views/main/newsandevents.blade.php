@extends('layouts.user')
@section('content')
<!-- About Us slider -->
<div class="row">
			<div id="demo" class="carousel slide" data-ride="carousel">
  
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="images/ukuni_slider/events.jpg" alt="Los Angeles" width="1100" height="300">
      <div class="carousel-caption" >
        <h1 style="font-size: 50px;">NEWS & EVENTS</h1>
        <hr width="10%" style="border-top-width: 3px;
    border-top-style: solid;
    border-top-color: #fff;" align="left">
        
<br><br><br><br>
      </div>   
    </div>
   
    
	 
	  </div>

	  
	</div>
		</div>
<br><br>
<!-- About Us slider -->
<!-- About Us Text -->

<div class="row">
	
	<div class="col-lg-8">

	<div class="row">
		<div class="col-lg-1"></div>
		<div class="col-lg-10">
			<div class="row">
				<div class="col-lg-4" >
					<div class="row">
						
						<div class="col-lg-11 " >
						<img src="images/blogs/canadian_way_of_life.jpg" width="100%">
						<a href="{{ route('canadian_way_of_life') }}"><h5 style="margin-top: 10px;">Canadian Way of Life</h5></a>
						<p style="font-size: 13px;font-weight: 700;color: #eb1e25">Article</p>
						<hr>
						<p style="font-size: 16px;">
							 
							Canada consistently ranks among the best place to live in numerous studies. In both 2018 and 2019


						</p>
						<span style="font-size: 15px;font-weight: 300">January 22, 2020 | Study In Canada</span><br><br>
						<a href="{{ route('canadian_way_of_life') }}"  id="changecolor" class="btn btn-default " style="background-color:#fff; color: #111;border-color: #1f0949; font-family:BusnosAires-light;font-size:20px;"><span >Read More</span> 
					    	<i class="fas fa-chevron-right"></i>
					    </a>
						<br><br><hr>
						</div>
						<div class="col-lg-1"></div>
					</div>
				</div>
				<div class="col-lg-4" >
					<div class="row">
						
						<div class="col-lg-11" >
						<img src="images/blogs/pakistani_student_canada.jpg" width="100%">
						<h5 style="margin-top: 10px;">Pakistani Student Canada</h5>
						<p style="font-size: 13px;font-weight: 700;color: #eb1e25">Article</p>
						<hr>
						<p style="font-size: 16px;">
							 
							20-Day Canada Study Permit Processing Via Student Direct Stream


						</p>
						<span style="font-size: 15px;font-weight: 300">January 22, 2020 | Study In Canada</span><br>
						
						<br>
						<a href="{{ route('pakistani_student_canada') }}"  id="changecolor" class="btn btn-default " style="background-color:#fff; color: #111;border-color: #1f0949; font-family:BusnosAires-light;font-size:20px;"><span >Read More</span> 
					    	<i class="fas fa-chevron-right"></i>
					    </a>
						<br><br><hr>
					</div>
					<div class="col-lg-1"></div>
					</div>	
				</div>
				<div class="col-lg-4" >
					<div class="row">
						
						<div class="col-lg-11 " >
						<img src="images/blogs/february_roadshow.jpg" width="100%">
						<a href="{{ route('canadian_way_of_life') }}"><h5 style="margin-top: 10px;">February Roadshow</h5></a>
						<p style="font-size: 13px;font-weight: 700;color: #eb1e25">Upcoming Event</p>
						<hr>
						<p style="font-size: 16px;">
							 
							A group of leading UK institutions are coming to Saudi Arabia to meet with students and their families. 


						</p>
						<span style="font-size: 15px;font-weight: 300">Jeddah: Sunday 23 Feb 2020</span><br>
						<span style="font-size: 15px;font-weight: 300">Riyadh: Tuesday 25 Feb 2020</span><br>
						<span style="font-size: 15px;font-weight: 300">Al Khobar: 27 Feb 2020</span><br><br>
						<a href="{{ route('february_roadshow') }}"  id="changecolor" class="btn btn-default " style="background-color:#fff; color: #111;border-color: #1f0949; font-family:BusnosAires-light;font-size:20px;"><span >Read More</span> 
					    	<i class="fas fa-chevron-right"></i>
					    </a>
						<br><br><hr>
						</div>
						<div class="col-lg-1"></div>
					</div>
				</div>
			</div>
		</div>
		<div class="col-lg-1"></div>
		
	</div>
	<br><br>
		<div class="row">
		<div class="col-lg-1"></div>
		<div class="col-lg-10">
			<div class="row">
				<div class="col-lg-4" >
					<div class="row">
						
						<div class="col-lg-11 " >
						<img src="images/blogs/phd_roadshow.jpg" width="100%">
						<h5 style="margin-top: 10px;">PhD Roadshow</h5>
						<p style="font-size: 13px;font-weight: 700;color: #eb1e25">Upcoming Event</p>
						<hr>
						<p style="font-size: 16px;">
							 
							Academics from leading UK Universities are coming to give workshops on key areas to assist candidates


						</p>
						
						<a href="{{ route('phd_roadshow')}}"  id="changecolor" class="btn btn-default " style="background-color:#fff; color: #111;border-color: #1f0949; font-family:BusnosAires-light;font-size:20px;"><span >Read More</span> 
					    	<i class="fas fa-chevron-right"></i>
					    </a>
						<br><br><hr>
						</div>
						<div class="col-lg-1"></div>
					</div>
				</div>
				<div class="col-lg-4" >
					<div class="row">
						
						<div class="col-lg-11" >
						<img src="images/blogs/facts_about_studying_in_australia.jpg" width="100%">
						<h5 style="margin-top: 10px;">Facts about studying in Australia</h5>
						<p style="font-size: 13px;font-weight: 700;color: #eb1e25">Article</p>
						<hr>
						<p style="font-size: 16px;">
							 
								Studying in Australia is a fantastic way to further your education and boost your career prospects.

						</p>
						<span style="font-size: 15px;font-weight: 300">December 23, 2020 | Study In Australia</span><br>
						
						<br>
						<a href="{{ route('facts_about_studying_in_australia')}}"  id="changecolor" class="btn btn-default " style="background-color:#fff; color: #111;border-color: #1f0949; font-family:BusnosAires-light;font-size:20px;"><span >Read More</span> 
					    	<i class="fas fa-chevron-right"></i>
					    </a>
						<br><br><hr>
					</div>
					<div class="col-lg-1"></div>
					</div>	
				</div>
				<div class="col-lg-4" >
					<div class="row">
						
						<div class="col-lg-11" >
						<img src="images/blogs/after_graduation.jpg" width="100%">
						<h5 style="margin-top: 10px;">After graduation</h5>
						<p style="font-size: 13px;font-weight: 700;color: #eb1e25">Article</p>
						<hr>
						<p style="font-size: 16px;">
							 
							Once you’ve completed your course, you have some decisions to make, whether you stay in Australia or return home.


						</p>
						<span style="font-size: 15px;font-weight: 300">January 23, 2020 | Study In Australia</span><br><br>
						
						
						<a href="{{ route('after_graduation') }}"  id="changecolor" class="btn btn-default " style="background-color:#fff; color: #111;border-color: #1f0949; font-family:BusnosAires-light;font-size:20px;"><span >Read More</span> 
					    	<i class="fas fa-chevron-right"></i>
					    </a>
						<br><br><hr>
					</div>
					<div class="col-lg-1"></div>
					</div>	
				</div>
			</div>
		</div>
		<div class="col-lg-1"></div>
		
	</div>
	
	<br><br>
		<div class="row">
		<div class="col-lg-1"></div>
		<div class="col-lg-10">
			<div class="row">
				<div class="col-lg-4" >
					<div class="row">
						
						<div class="col-lg-11 " >
						<img src="images/blogs/second_passport.jpg" width="100%">
						<h5 style="margin-top: 10px;">Why you need a second passport?</h5>
						<p style="font-size: 13px;font-weight: 700;color: #eb1e25">Article</p>
						<hr>
						<p style="font-size: 16px;">
							 
							Before World War I, you didn’t need a passport for international travel.


						</p><span style="font-size: 15px;font-weight: 300">December 23, 2020 | Study In Australia</span><br><br>
						
						<a href="{{ route('second_passport')}}"  id="changecolor" class="btn btn-default " style="background-color:#fff; color: #111;border-color: #1f0949; font-family:BusnosAires-light;font-size:20px;"><span >Read More</span> 
					    	<i class="fas fa-chevron-right"></i>
					    </a>
						<br><br><hr>
						</div>
						<div class="col-lg-1"></div>
					</div>
				</div>
				<div class="col-lg-4" >
					<div class="row">
						
						<div class="col-lg-11" >
						<img src="images/blogs/why_we_immigrate_to_canada.jpg" width="100%">
						<h5 style="margin-top: 10px;">Why we immigrate to Canada?</h5>
						<p style="font-size: 13px;font-weight: 700;color: #eb1e25">Article</p>
						<hr>
						<p style="font-size: 16px;">
							 
								The economic impact of immigration is an important topic in Canada. While the immigration rate has 

						</p>
						<span style="font-size: 15px;font-weight: 300">January 23, 2020 | Study In Canada</span><br>
						
						<br>
						<a href="{{ route('why_we_immigrate_to_canada')}}"  id="changecolor" class="btn btn-default " style="background-color:#fff; color: #111;border-color: #1f0949; font-family:BusnosAires-light;font-size:20px;"><span >Read More</span> 
					    	<i class="fas fa-chevron-right"></i>
					    </a>
						<br><br><hr>
					</div>
					<div class="col-lg-1"></div>
					</div>	
				</div>
				<div class="col-lg-4" >
					<div class="row">
						
						<div class="col-lg-11" >
						<img src="images/blogs/usf_scholarship.jpg" width="100%">
						<h5 style="margin-top: 10px;">USF Scholarship</h5>
						<p style="font-size: 13px;font-weight: 700;color: #eb1e25">News</p>
						<hr>
						<p style="font-size: 16px;">
							 
							The University of South Florida (USF) is offering some generous scholarships for top students 


						</p>
						<span style="font-size: 15px;font-weight: 300">January 23, 2020 | News</span><br><br>
						
						
						<a href="{{ route('usf_scholarship') }}"  id="changecolor" class="btn btn-default " style="background-color:#fff; color: #111;border-color: #1f0949; font-family:BusnosAires-light;font-size:20px;"><span >Read More</span> 
					    	<i class="fas fa-chevron-right"></i>
					    </a>
						<br><br><hr>
					</div>
					<div class="col-lg-1"></div>
					</div>	
				</div>
			</div>
		</div>
		<div class="col-lg-1"></div>
		
	</div>

	</div>
	<div class="col-lg-3" >
		@include('layouts.queryForm')
	</div>
	<div class="col-lg-1"></div>
</div><br><br>
<!-- About Us Text -->
@endsection