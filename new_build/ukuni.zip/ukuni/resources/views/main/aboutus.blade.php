@extends('layouts.user')
@section('content')
<!-- About Us slider -->

<div class="row">
			<div id="demo" class="carousel slide" data-ride="carousel">
  
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="images/ukuni_slider/aboutus.jpg" alt="Los Angeles" width="1100" height="300">
      <div class="carousel-caption" >
        <h1 style="font-size: 50px;">ABOUT US</h1>
        <hr width="10%" style="border-top-width: 3px;
    border-top-style: solid;
    border-top-color: #fff;" align="left">
        
<br><br><br><br>
      </div>   
    </div>
   
    
	 
	  </div>

	  
	</div>
		</div>
<br><br>
<!-- About Us slider -->
<!-- About Us Text -->
<div class="container-fluid">
<div class="row">
	<div class="col-lg-1"></div>
	<div class="col-lg-7">
		<p style="font-size: 50px; text-align: left;color: #1f0949;">About <strong style="font-size: 50px; color: #eb1e25;">UKUNI</strong></p>
		<hr width="10%" style="border-top-width: 3px;
    border-top-style: solid;
    border-top-color: #1f0949;" align="left">
		<p >We are a specialised Educational Counselling and Advisory Company. We offer advice and counselling to students, parents and employers that wish to access the educational opportunities available at our partner institutions</p>
		<p>We also assist students that wish to develop their English language at schools and language colleges across that English speaking countries. We could cater for almost all needs and requests.</p>
		<p>We also have several options for Young Learners to develop their English during the summer in a secure and enjoyable environment. Parents could choose from summer schools, summer camps, English with football or English with activities.</p>
		<p>We started in 2008 to provide expert services to students that wish to study in the UK. The experience of the founders go back to 1996 and long relations with UK education sector.</p>
		<p>The accumulated knowledge about education opportunities and options is added to the physical knowledge of the cities and towns gives students a wealth of information to enable them to make well informed decisions about their studies.</p>
		<p>We represent tens of Universities in UK, USA, Canada, Australia and New Zealand in addition to many of language and training providers in English language speaking countries. We have an option for any request.</p>
		

		<p style="font-weight: 700;">Over the past ten years, we have helped thousands of students from Saudi Arabia, and other countries, to access educational opportunities. Many of these candidates have graduated and are in senior positions.</p>

	</div>
	<div class="col-lg-3 university-logo" >
		@include('layouts.queryForm')
	</div>
	<div class="col-lg-1"></div>
</div>
</div>
<br><br>
<!-- About Us Text -->
<!-- The Team 
<div class="row">
	<div class="col-lg-1"></div>
	<div class="col-lg-10">
		<p style="font-size: 50px; text-align: left;color: #1f0949;">The <strong style="font-size: 50px; color: #eb1e25;">Team</strong></p>
		<hr width="10%" style="border-top-width: 3px;
    border-top-style: solid;
    border-top-color: #1f0949;" align="left">
	</div>
	<div class="col-lg-1"></div>
</div><br>
<div class="row">
	<div class="col-lg-1"></div>
	<div class="col-lg-10">
		<div class="row">
			<div class="col-lg-4">
				<img src="images/team/01.jpg"  width="70%">
				<p style="font-size: 25px; text-align: left;color: #1f0949;">Mr. Ibrahim Al-Najjar</strong></p>
				<p>Mr. Ibrahim Al-Najjar, founder and CEO of UKuni enjoys a long experience that goes back to 1996 and long relations with UK education sector. Mr. Al-Najjar worked as education manager and assistant director of the British Council in Saudi Arabia, and took part in many initiatives to promote the educationalrelationships between Saudi Arabia and the UK. Mr. Al-Najjar was also supported by a dedicatedand enthusiastic team of education advisersand counsellors.</p>
			</div>
			<div class="col-lg-4">
				<img src="images/team/01.jpg"  width="70%">
				<p style="font-size: 25px; text-align: left;color: #1f0949;">Taha Ahmed,</strong></p>
				<p>Taha Ahmed, was, and still a key player in UKuni and was awarded the British Council Certificate for Education Advisers. Taha manages the Riyadh office and has a good team to support him.</p>
				
			</div>
			<div class="col-lg-4">
				<img src="images/team/01.jpg"  width="70%">
				<p style="font-size: 25px; text-align: left;color: #1f0949;">Fuad Hariz</strong></p>
				<p>Fuad Hariz is another member of the team and has also been awarded the British Council Certificate for Education Advisers. Fuad manages the Jeddah office and has a good team to support him.</p>
				
			</div>
		</div>
	</div>
	<div class="col-lg-1"></div>
</div>
The Team -->
@endsection
