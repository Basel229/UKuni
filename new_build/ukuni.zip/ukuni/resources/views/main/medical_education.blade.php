@extends('layouts.user')
@section('content')

<!-- About Us slider -->
<div class="row">
			<div id="demo" class="carousel slide" data-ride="carousel">
  
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="images/ukuni_slider/medicine.jpg" alt="Los Angeles" width="1100" height="300">
      <div class="carousel-caption" >
        <h1 style="font-size: 50px;">Medical Education</h1>
        <hr width="10%" style="border-top-width: 3px;
    border-top-style: solid;
    border-top-color: #fff;" align="left">
        
<br><br>

<br><br>
      </div>   
    </div>
   
    
	 
	  </div>

	  
	</div>
		</div>
<br><br>
<!-- About Us slider -->
<!-- About Us Text -->

<div class="row">
	
	<div class="col-lg-8">
		<p style="font-size: 50px; text-align: left;color: #1f0949;">Medical <strong style="font-size: 50px; color: #eb1e25;">Education</strong></p>
		



	<p style="font-size: 17px;">The UK is one of the leading countries in the world for medical education and training. Due to the government restrictions, medical schools cannot accept as many international students as they want. One way to allow international students to access the UK excellence in medical education is to teach the same degree outside the UK.</p>
    <p style="font-size: 17px;">Queen Mary, University of London, has one of the oldest medical schools in the UK, Barts and the London School of Medicine and Dentistry has now established the MBBS programme in Malta.</p>

    <p style="font-size: 17px;">QMUL has a strong core curriculum is underpinned by research, you will be linking your learning to the work of the faculty, from the laboratory bench to new drugs to public health interventions. With less emphasis on traditional lectures, problem-based learning in small groups encourages you to take an independent approach to clinical scenarios.</p>

    <p style="font-size: 17px;">You’ll develop practical experience through attachments with local general practices, and in your third, fourth and fifth years you’ll spend time in primary and secondary care facilities in Malta and Gozo.</p>


	
	<br><br>

	</div>
	<div class="col-lg-3" >
		@include('layouts.queryForm')
	</div>
	<div class="col-lg-1"></div>
</div><br><br>
<!-- About Us Text -->
@endsection