@extends('layouts.user')
@section('content')
<!-- About Us slider -->
<div class="row">
			<div id="demo" class="carousel slide" data-ride="carousel">
  
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="images/ukuni_slider/study_in_uk.jpg" alt="Los Angeles" width="1100" height="300">
      <div class="carousel-caption" >
        <h1 style="font-size: 50px;">STUDY IN UK</h1>
        <hr width="10%" style="border-top-width: 3px;
    border-top-style: solid;
    border-top-color: #fff;" align="left">
        
<br><br><br><br>
      </div>   
    </div>
   
    
	 
	  </div>

	  
	</div>
		</div>

<!-- About Us slider -->
<!-- About Us Text -->
<!-- Search Filter -->
<div class="row" style="background-color: #eb1e25;">
	
	<div class="col-lg-2"></div>
	<div class="col-lg-8" ><br>
		<p style="font-size: 35px; text-align: center;color: #fff;">Search <strong style="font-size: 35px; color: #fff;">In UK. . . </strong></p>
		@if(session()->has('message'))
                <div class="alert alert-danger">
                    {{ session()->get('message') }}
                </div>
            @endif    
    <form method="get" action="{{ route('ukuniversities') }}" class="form-inline">
    	
    	{{ csrf_field() }}
    	<select name="level" class="form-control form_field_size" style="height: 45px;
			width: 30%;">
			<option value="">Select Level of Studies</option>
			<option value="Undergraduate">Undergraduate</option>
			<option value="Postgraduate">Postgraduate</option>
			<option value="Postgraduate Diploma">Postgraduate Diploma</option>
			<option value="Diploma">Diploma</option>
			<option value="Foundation Diploma">Foundation Diploma</option>
			<option value="Certificate">Certificate</option>
    		
    	</select>&nbsp;
    	<select name="discipline" class="form-control form_field_size" style="height: 45px;
			width: 30%;">
    		<option value="">Select Discipline</option>
    		
    		@for($i=0; $i< $totalcount;$i++)
    		<option value="{{ $selecteddata[$i] }}">{{ $selecteddata[$i] }}</option>
    		@endfor

    		
    		
    	</select>&nbsp;
    	<select name="university" class="form-control form_field_size" style="height: 45px;
			width: 25%;">
			<option value="">Select University</option>
    		<option value="Anglia Ruskin University Cambridge">Anglia Ruskin University Cambridge</option>
    		<option value="Aston University">Aston University</option>
    		<option value="Bangor University Bangor">Bangor University Bangor</option>
    		<option value="BPP University">BPP University</option>
    		<option value="Brunel University London Uxbridge">Brunel University London Uxbridge</option>
    		<option value="Cardiff University">Cardiff University</option>
    		<option value="Coventry University">Coventry University</option>
    		<option value="Glasgow Caledonian University">Glasgow Caledonian University</option>
    		<option value="Kings College London">King's College London</option>
    		<option value="Liverpool John Moores University">Liverpool John Moores University</option>
    		<option value="London South Bank University Southwark">London South Bank University Southwark</option>
    		<option value="Manchester Metropolitan University">Manchester Metropolitan University</option>
    		<option value="Middlesex University Barnet">Middlesex University Barnet</option>
    		<option value="Northumbria University, Newcastle">Northumbria University, Newcastle</option>
    		<option value="Oxford Brookes University">Oxford Brookes University</option>
    		<option value="Queen Mary University of London">Queen Mary University of London</option>
    		<option value="Queens University Belfast">Queen's University Belfast</option>
    		<option value="Royal Holloway, University of London Egham">Royal Holloway, University of London Egham</option>
    		<option value="Swansea University">Swansea University</option>
    		<option value="Teesside University, Middlesbrough Tees Valley">Teesside University, Middlesbrough Tees Valley</option>
    		<option value="Ulster University">Ulster University</option>
    		<option value="University of Aberdeen">University of Aberdeen</option>
    		<option value="University of Bradford">University of Bradford</option>
    		<option value="University of Brighton">University of Brighton</option>
    		<option value="University of Central Lancashire">University of Central Lancashire</option>
    		<option value="University of Dundee">University of Dundee</option>
    		<option value="University of East Anglia">University of East Anglia</option>
    		<option value="University of Essex Colchester">University of Essex Colchester</option>
    		<option value="University of Exeter">University of Exeter</option>
    		<option value="University of Kent Canterbury">University of Kent Canterbury</option>
    		<option value="University of Leeds">University of Leeds</option>
    		<option value="University of Lincoln">University of Lincoln</option>
    		<option value="University of Liverpool">University of Liverpool</option>
    		<option value="University of Manchester">University of Manchester</option>
    		<option value="University of Plymouth">University of Plymouth</option>
    		<option value="University of Reading">University of Reading</option>
    		<option value="University of Roehampton London">University of Roehampton London</option>
    		<option value="University of Salford">University of Salford</option>
    		<option value="University of Sheffield">University of Sheffield</option>
    		<option value="University of Stirling">University of Stirling</option>
    		<option value="University of Surrey">University of Surrey</option>
    		<option value="University of Sussex">University of Sussex</option>
    		<option value="University of York">University of York</option>
    		
    		
    		
    		
    	</select>&nbsp;
    	
    	
    	
    	<input type="submit" name="submit" value="Search" class="btn btn-info" style="height: 45px;width: 100px;">
    </form>
	<br><br><br>
	</div>
	<div class="col-lg-2"></div>
</div><br><br>
<!-- Search Filter -->
<div class="row">
	
	<div class="col-lg-8">
		<p style="font-size: 50px; text-align: left;color: #1f0949;">Why <strong style="font-size: 50px; color: #eb1e25;">chooses UK?</strong></p>
		<hr width="10%" style="border-top-width: 3px;
    border-top-style: solid;
    border-top-color: #1f0949;" align="left">
    <br>
    <h3 style="color: #eb1e25;">Gain world class education </h3><br>
    <ul>
    	<li>Four of the top six universities in the world are in the UK.</li>
    	<li>The UK rank send in the world for the university industry collaboration.</li>
    	<li>The UK is a world leading research nation. </li>
    	<li>UK universities and research institutions have produced 88 noble prize winners since 1903.</li>
    </ul>
     <br>
    <h3 style="color: #eb1e25;">Get the best career  </h3><br>
    <ul>
    	<li>UK education can improve your career prospects, and even boost your earnings: 5 UK universities were in the top ten universities in terms of employability of the graduates. </li>
    	<li>The 2013/2014 QS world university rankings found that employers worldwide consider UK graduates among the most “employable “. From a global survey of 27,000 graduates’ employers, Five UK universities were ranked in the top 10.</li>
    	<li>UK/educated international graduates achieve relatively higher average salaries than if they had been educated at home.</li>
    	
    </ul>
    <br>
    <h3 style="color: #eb1e25;">The adventure of your life </h3><br>
    <ul>
    	<li>Studying in the UK is a chance to discover its unique culture, cities and countryside. Across England, Scotland, Wales and Northern Ireland, there’s so much to discover. Luckily, it is easy to travel around the UK, and to explore Europe from the UK. </li>
    </ul>
    <br>
    <h3 style="color: #eb1e25;">Save time</h3><br>
    <ul>
    	<li>Studying in the UK is 25% shorter than North American style education. Most full time bachelor’s degrees, typically last for 3 years, compared with 4 or 5 years in many countries. Most full time British Masters last for 1 year.</li>
    </ul>
    <br>
    <h3 style="color: #eb1e25;">Save money </h3><br>
    <ul>
    	<li>Tuition fees of US universities is double the fees for comparable ranking UK universities. The cost of living is also 50% higher in the US. </li>
    </ul>
    <br>
    <h3 style="color: #eb1e25;">Join a friendly international community </h3><br>
    <ul>
    	<li>The UK is a friendly and welcoming place for all people of all counties, cultures and faiths. In 2012, over 500,000 international students from 200 countries studied at UK schools, collages and universities, and a further 600,000 students came to study English. In fact at UK universities and higher education institutions, over 16,8% of all students and over 25% of academics and professors are from outside the UK. </li>
    </ul>
    <br>
    <h3 style="color: #eb1e25;">Discover create and innovate </h3><br>
    <ul>
    	<li>The UK is one of the most exciting and productive places in the world for research, creativity and innovation. If you have a passion for learning and want to be at the forefront of your subject, this is the place to be.</li>
    </ul>
    <br><br><br>
    <!-- Blog Section -->
    	<div class="row">
		<div class="col-lg-1"></div>
		<div class="col-lg-10">
			<div class="row">
				<div class="col-lg-6" >
					<div class="row">
						
						<div class="col-lg-11 " >
						<img src="images/blogs/why_study_in_the_uk.jpg" width="100%">
						<a href="{{ route('canadian_way_of_life') }}"><h5 style="margin-top: 10px;">Why Study In The UK</h5></a>
						<p style="font-size: 13px;font-weight: 700;color: #eb1e25">Article</p>
						<hr>
						<p style="font-size: 16px;">
							 
							Why study in the UK? The UK and its universities have an undisputed reputation for academic excellence


						</p>
						<span style="font-size: 15px;font-weight: 300">January 27, 2020 | Study In UK</span><br><br>
						<a href="{{ route('why_study_in_the_uk') }}"  id="changecolor" class="btn btn-default " style="background-color:#fff; color: #111;border-color: #1f0949; font-family:BusnosAires-light;font-size:20px;"><span >Read More</span> 
					    	<i class="fas fa-chevron-right"></i>
					    </a>
						<br><br><hr>
						</div>
						<div class="col-lg-1"></div>
					</div>
				</div>
				<div class="col-lg-6" >
					<div class="row">
						
						<div class="col-lg-11" >
						<img src="images/blogs/uk_study_system.jpg" width="100%">
						<h5 style="margin-top: 10px;">UK Education System</h5>
						<p style="font-size: 13px;font-weight: 700;color: #eb1e25">Article</p>
						<hr>
						<p style="font-size: 16px;">
							 
							The education system in the UK is divided into four main parts, primary education, 


						</p>
						<span style="font-size: 15px;font-weight: 300">January 27, 2020 | Study In UK</span><br>
						
						<br>
						<a href="{{ route('uk_education_system') }}"  id="changecolor" class="btn btn-default " style="background-color:#fff; color: #111;border-color: #1f0949; font-family:BusnosAires-light;font-size:20px;"><span >Read More</span> 
					    	<i class="fas fa-chevron-right"></i>
					    </a>
						<br><br><hr>
					</div>
					<div class="col-lg-1"></div>
					</div>	
				</div>

			</div>
		</div>
		<div class="col-lg-1"></div>
		
	</div>
    <!--  Blog Section -->
    
	
	<div class="row">
		
	<div class="col-lg-11">

	</div>	
	<div class="col-lg-1"></div>	
	</div>

	</div>
	<div class="col-lg-3" >
		<p style="font-size: 25px; text-align: left;color: #fff;background-color: #1f0949;;padding: 25px;">If you have any query, Send us a message</p>
		<form method="" action="#" style="background-color: #f8f8f8;padding: 15px;" >
			<input type="text" name="full_name" class="form-control" placeholder="Enter Full Name"><br>
			<input type="email" name="email" class="form-control" placeholder="Enter Email Address"><br>
			<input type="number" name="phone_number" class="form-control" placeholder="Enter Phone Number"><br>
			<select name="destination" class="form-control">
				<option value="">Select Your Destination</option>
				<option value="1">UK</option>
				<option value="1">USA</option>
				<option value="1">Australia</option>
				<option value="1">New Zealand</option>
				<option value="1">Canada</option>
			</select><br>
			<select name="city" class="form-control">
				<option value="">Select Your City</option>
				<option value="1">UK</option>
				<option value="1">USA</option>
				<option value="1">Australia</option>
				<option value="1">New Zealand</option>
				<option value="1">Canada</option>
			</select><br>
			<textarea class="form-control" name="message" rows="4" placeholder="Type your message here. . .">
				
				
			</textarea><br>
			<a href="#" id="changecolor"  class="btn btn-default centerbutton" style="background-color:#fff; color: #111;border-color: #1f0949; font-family:BusnosAires-light;font-size:20px;"><span >Submit</span> 
					    	<i class="fas fa-chevron-right"></i>
					    </a>
		</form>
	</div>
	<div class="col-lg-1"></div>
</div><br><br>
<!-- About Us Text -->
@endsection