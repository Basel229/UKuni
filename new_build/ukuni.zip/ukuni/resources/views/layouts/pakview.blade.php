 <nav class="navbar navbar-expand-lg navbar-light bg-info" >
  <a class="navbar-brand" href="{{ route('index') }}" style="color: #fff;font-size:17px;">{{ __('text.Home') }}</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavDropdown">
    <ul class="navbar-nav" style="color: #fff;">
      <li class="nav-item " >
        <a class="nav-link" style="color: #fff;font-size: 17px;;" href="{{ route('aboutus') }}"   >
          About Us
        </a>
        
      </li>
<li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="study_abroad.html" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="color: #fff;font-size: 17px;">
          Study Abroad
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink" style="width: 250px;padding: 20px;">
        <a class="dropdown-item dropdown_color_change" href="{{ route('study_abroad') }}" style="padding: 5PX;font-size: 20px;">Overview</a>
         <a class="dropdown-item dropdown_color_change" href="{{ route('study_in_uk') }}" style="padding: 5PX;"> <img src="{{ asset('images/uk.jpg') }}" width="40"><span>    UK</span></a>
         <a class="dropdown-item dropdown_color_change" href="{{ route('study_in_usa') }}" style="padding: 5PX;"> <img src="{{ asset('images/usa.jpg') }}" width="40"><span>    USA</span></a>
         <a class="dropdown-item dropdown_color_change" href="{{ route('study_in_australia') }}" style="padding: 5PX;"> <img src="{{ asset('images/australia.jpg') }}" width="40"><span>    Australia</span></a>
         <a class="dropdown-item dropdown_color_change" href="{{ route('study_in_newzealand') }}" style="padding: 5PX;"> <img src="{{ asset('images/newzealand.jpg') }}" width="40"><span>    New Zealand</span></a>
         <a class="dropdown-item dropdown_color_change" href="{{ route('study_in_canada') }}" style="padding: 5PX;"> <img src="{{ asset('images/canada.jpg') }}" width="40"><span>    Canada</span></a>
         <a class="dropdown-item dropdown_color_change" href="{{ route('study_in_ireland') }}" style="padding: 5PX;"> <img src="{{ asset('images/ireland.jpg') }}" width="40"><span>    Ireland</span></a>
         <a class="dropdown-item dropdown_color_change" href="{{ route('study_in_middleeast') }}" style="padding: 5PX;"> <img src="{{ asset('images/middleeast.png') }}" width="40"><span>    Middle East</span></a>
         
          
        </div>
      </li>
      <li class="nav-item ">
        <a class="nav-link " href="{{ route('study_english') }}"    style="color: #fff;font-size: 17px;;">
          Study English
        </a>
        
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="color: #fff;font-size: 17px;">
          Immigration & Citizenship
        </a>
        <div class="dropdown-menu " aria-labelledby="navbarDropdownMenuLink" style="width: 250px;padding: 20px;">
         <a class="dropdown-item dropdown_color_change" href="{{ route('immigration') }}"> <img src="{{ asset('images/immigration.png') }}" width="40"><span> Immigration</span></a>
         <a class="dropdown-item dropdown_color_change" href="{{ route('citizenship') }}"> <img src="{{ asset('images/citizenship.png') }}" width="40"><span> Citizenship</span></a>
        
          
        </div>
      </li>
      <li class="nav-item ">
        <a class="nav-link " href="{{ route('medical_education') }}"    style="color: #fff;font-size: 17px;">
          Medical Education
        </a>
        
      </li>
      <li class="nav-item ">
        <a class="nav-link " href="{{ route('newsandevents') }}"   style="color: #fff;font-size: 17px;" >
          News & Events
        </a>
        
      </li>
      

     
      
    </ul>
  </div>
</nav>

</div>
</div>


