<?php

return
[

	'SEARCH_UNIVERSITY' => "حث الجامعة
",   'SEND_US_MESSAGE' => "أأرسل رسالة
",	'FREE_CONSULTANCY' => "استشارة مجانية
",	'Home' => "الصفحة الرئيسية
",	'About' => "حول
",	'Study_abroad' => "حدراسة في الخارج
",	'Study_in_uk' => "حالدراسة في المملكة المتحدة
",  'Study_in_usa' => "حدراسة في الولايات المتحدة الأمريكية
",  'Study_in_australia' => "حدراسة في استراليا
",  'Study_in_newzealand' => "حالدراسة في نيوزيلندا
",  'Study_in_canada' => "حادرس في كندا
",	'Study_english' => "حادرس الانجليزية
",	'medical_education' => "حالتعليم الطبي
",	'news_and_events' => "حالأخبار و الأحداث
",
];