<?php

return
[

	'SEARCH_UNIVERSITY' => "ÜNİVERSİTE ARA",
	'SEND_US_MESSAGE' => "İleti",
	'FREE_CONSULTANCY' => "Bizi Arayın",
	'Home' => "Anasayfa", 
		'About' => "hakkında",	
		'Study_abroad' => "yurt dışında okumak",	
		'Study_in_uk' => "İngiltere'de eğitim",
		'Study_in_usa' => "abd'de eğitim",
		'Study_in_australia' => "avustralya'da eğitim",  
		'Study_in_newzealand' => "yeni zelanda'da eğitim",  
		'Study_in_canada' => "kanada'da eğitim",	
		'Study_english' => "İngilizce çalışmak",	
		'medical_education' => "Tıp eğitimi",
		'news_and_events' => "Haberler ve Olaylar",
		'immigration_and_citizenship' => "göç ve vatandaşlık",
		'immigration' => "göç",
		'citizenship' => "vatandaşlık",


];